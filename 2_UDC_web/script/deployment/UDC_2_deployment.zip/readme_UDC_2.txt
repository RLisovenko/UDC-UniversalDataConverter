UDC 2 - Quick start
Copy ALL files to 2_UDC_web\script\deployment.
Read INSTALL_UDC_2.md first. Install Docker Desktop and configure docker\.env.

1. First installation: install_udc_2.cmd
2. Local restart: start_udc_2_local_Docker&SQL.cmd
3. Public tunnel after local start: start_udc_2_tunnel_loc-public.cmd
4. Local restart plus public tunnel: start_udc_2_tunnel_loc-public_all.cmd

udc.ps1 must remain next to the CMD files.
The All script requires first installation to have completed.
Install cloudflared before starting a tunnel. Keep the tunnel window open.