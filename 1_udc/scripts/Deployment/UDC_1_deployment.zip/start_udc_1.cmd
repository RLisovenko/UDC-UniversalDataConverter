@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "UDC1_ROOT=%~dp0"
set "UDC1_LAUNCHER=%~f0"
set "UDC1_HELPER=%TEMP%\udc1-%RANDOM%-%RANDOM%.py"
where python.exe >nul 2>nul
if errorlevel 1 (
  echo ERROR: Install Python 3.12 x64 with tkinter and Add Python to PATH.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$s=[IO.File]::ReadAllText($env:UDC1_LAUNCHER); $m='# BEGIN_UDC1_PYTHON'; $i=$s.LastIndexOf($m); if($i -lt 0){exit 1}; [IO.File]::WriteAllText($env:UDC1_HELPER,$s.Substring($i+$m.Length),[Text.UTF8Encoding]::new($false))"
if errorlevel 1 (
  echo ERROR: Cannot prepare launcher.
  pause
  exit /b 1
)
python.exe "%UDC1_HELPER%"
set "UDC1_EXIT=%ERRORLEVEL%"
del /q "%UDC1_HELPER%" >nul 2>nul
echo.
pause
exit /b %UDC1_EXIT%
# BEGIN_UDC1_PYTHON
import hashlib
import os
from pathlib import Path
import re
import runpy
import subprocess
import sys
import time

SQL_FILES = (
    'sql_cr_data_measurement.sql',
    'sql_alterType_data_measurement.sql',
    'sql_cr_data_measure_map.sql',
    'sql_alter_DataValue_data_measurement_map.sql',
    'SQL_field_mapping_config.sql',
    'SQL_CR_list_measurement_parameter.sql',
    'SQL_CR_vw_data_measure_map.sql',
    'SQL_INSERT_t1.sql',
)

def batches(text):
    text = re.sub(r'^\s*USE\s+(?:\[Converter_UDC\]|Converter_UDC)\s*;?\s*$', '', text, flags=re.M | re.I)
    return [b.strip() for b in re.split(r'^\s*GO\s*(?:--[^\n]*)?$', text, flags=re.M | re.I) if b.strip()]

def identifier(name):
    return '[' + name.replace(']', ']]') + ']'

def main():
    root = Path(os.environ['UDC1_ROOT']).resolve()
    if not (root / 'udc_ui.py').is_file():
        raise RuntimeError('Copy start_udc_1.cmd into the 1_udc folder, next to udc_ui.py.')
    os.chdir(root)
    requirements = root / 'requirements.txt'
    config = root / 'utils' / 'CONSTANT_config.py'
    for path in (requirements, config, *(root / 'Sql' / name for name in SQL_FILES)):
        if not path.is_file():
            raise RuntimeError('Missing project file: ' + str(path))
    if sys.version_info < (3, 11):
        raise RuntimeError('Python 3.11 or newer is required. Recommended: Python 3.12 x64.')
    import tkinter
    env = root / '.venv_udc1'
    python = env / 'Scripts' / 'python.exe'
    if '--environment-ready' not in sys.argv:
        if not python.exists():
            print('Creating isolated Python environment...', flush=True)
            subprocess.run([sys.executable, '-m', 'venv', str(env)], check=True)
        fingerprint = hashlib.sha256(requirements.read_bytes()).hexdigest()
        stamp = env / 'udc_requirements.sha256'
        if not stamp.exists() or stamp.read_text().strip() != fingerprint:
            print('Installing exact versions from requirements.txt...', flush=True)
            subprocess.run([str(python), '-m', 'pip', 'install', '-r', str(requirements)], check=True)
            stamp.write_text(fingerprint)
        return subprocess.call([str(python), __file__, '--environment-ready'])
    import pyodbc
    import pandas
    cfg = runpy.run_path(str(config))
    driver = cfg['DRIVER']
    match = re.search(r'DRIVER=\{([^}]+)\}', driver, re.I)
    if not match or match.group(1) not in pyodbc.drivers():
        raise RuntimeError('Install Microsoft ODBC Driver 18 for SQL Server x64 (or the driver specified in CONSTANT_config.py).')
    server, database = cfg['SERVER'], cfg['DATABASE']
    def connect(db, autocommit=False):
        # ODBC braces protect semicolons in configured values.
        esc = lambda value: '{' + value.replace('}', '}}') + '}'
        return pyodbc.connect(driver + 'SERVER=' + esc(server) + ';DATABASE=' + esc(db)
            + ';Trusted_Connection=yes;Encrypt=yes;TrustServerCertificate=yes;',
            timeout=5, autocommit=autocommit)
    print('SQL Server: ' + server + ' | Database: ' + database, flush=True)
    print('Waiting for SQL Server (up to 60 seconds)...', flush=True)
    deadline = time.monotonic() + 60
    while True:
        try:
            master = connect('master', True)
            break
        except pyodbc.Error:
            if time.monotonic() >= deadline:
                raise
            time.sleep(2)
    try:
        exists = master.execute('SELECT DB_ID(?)', database).fetchone()[0] is not None
        if not exists:
            answer = input('Database is missing. Create it with synthetic demo data? Type YES: ')
            if answer.strip() != 'YES':
                raise RuntimeError('Database creation cancelled.')
            master.execute('CREATE DATABASE ' + identifier(database))
    finally:
        master.close()
    connection = connect(database)
    try:
        count = connection.execute('SELECT COUNT(*) FROM sys.objects WHERE is_ms_shipped=0').fetchone()[0]
        if count == 0:
            if exists and input('Database is empty. Initialize demo schema? Type YES: ').strip() != 'YES':
                raise RuntimeError('Initialization cancelled.')
            print('Creating schema and synthetic demo records...', flush=True)
            try:
                for name in SQL_FILES:
                    print('  ' + name, flush=True)
                    for sql in batches((root / 'Sql' / name).read_text(encoding='utf-8-sig')):
                        cursor = connection.cursor()
                        try:
                            cursor.execute(sql)
                            while cursor.nextset():
                                pass
                        finally:
                            cursor.close()
                connection.commit()
            except Exception:
                connection.rollback()
                print('Schema transaction rolled back. Database was not deleted.')
                raise
        # Existing databases are inspected only; no migrations or seed inserts.
        checks = (
            'SELECT TOP (0) PatientID, PatientName, MeasurDate, ParameterID, ParameterName, MeasurVal, UnitCode FROM dbo.data_measurement',
            'SELECT TOP (0) SubjID, SubjName, ImpDate, EventDate, ExpDate, ParameterID, ParameterName, DataValue, Unit, Comment FROM dbo.data_measure_map',
            'SELECT TOP (0) SubjID, SubjName, EventDate, ExpDate, ParameterID, ParameterName, DataValue, Unit, Comment FROM dbo.vw_data_measure_map',
            'SELECT TOP (0) Direction, SourceSystem, SourceField, InTargetField, TransformExpr, IsActive FROM dbo.field_mapping_config',
        )
        for sql in checks:
            connection.execute(sql).fetchall()
        connection.rollback()
    finally:
        connection.close()
    for folder in ('import', 'export', 'output'):
        (root / folder).mkdir(exist_ok=True)
    print('Database check passed. Opening UDC desktop application...', flush=True)
    return subprocess.call([sys.executable, str(root / 'udc_ui.py')], cwd=str(root))

if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as exc:
        print('\nERROR: ' + str(exc), file=sys.stderr)
        print('See INSTALL_UDC_1.md. Existing database contents are not reset.', file=sys.stderr)
        sys.exit(1)
